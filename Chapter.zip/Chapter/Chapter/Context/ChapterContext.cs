﻿using Microsoft.EntityFrameworkCore;

[15:15] Matheus de Holanda Pereira Ribeiro
using Microsoft.EntityFrameworkCore;
 
namespace Chapter.Context

{

    public class ChapterContext : DbContext

    {

        public ChapterContext()

        {

        }

        public ChapterContext(DbContextOptions<ChapterContext> options) : base(options)

        {

        }

        // vamos utilizar esse método para configurar o banco de dados

        protected override void

        OnConfiguring(DbContextOptionsBuilder optionsBuilder)

        {

            if (!optionsBuilder.IsConfigured)

            {

                // cada provedor tem sua sintaxe para especificação

                optionsBuilder.UseSqlServer("Data Source = DESKTOP-J86NPJR\\SQLEXPRESS; Initial catalog = Chapter; Integrated Security  = True; TrustSerrverCertificate = True");

            }

        }
        public DbSet <Livros> Livros { get; set; }
    }

}
