﻿namespace Chapter.Models
{
    public class Livros
    {
        public int Id { get; set; }

        public string? Titulo { get; set; }

        public int QuantidadedePaginas { get; set; }

        public bool Disponivel {  get; set; }


    }
}
